import React, { useState, useEffect } from 'react';
import './App.css';

const Quiz = () => {
  const [quizData, setQuizData] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(60); // Initial countdown time
  const [timer, setTimer] = useState(null);

  useEffect(() => {
    import('./answers.json').then((data) => setQuizData(data.default));
  }, []);

  useEffect(() => {
    // Start the countdown timer when the component mounts
    if (currentQuestion < quizData.length && !showResult) {
      setTimer(setInterval(updateTimer, 1000));
    }

    // Clear the timer when the component unmounts or when the quiz is completed
    return () => {
      clearInterval(timer);
    };
  }, [currentQuestion, quizData, showResult]);

  const updateTimer = () => {
    // Update the timer display
    setTimeRemaining((prevTime) => {
      if (prevTime === 0) {
        clearInterval(timer);
        alert('Time is up! Quiz failed.'); // Customize this message or redirect to a failure page
        setShowResult(true);
      }
      return prevTime > 0 ? prevTime - 1 : prevTime;
    });
  };

  const handleAnswerClick = (selectedOption) => {
    if (selectedOption === quizData[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    if (currentQuestion < quizData.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setTimeRemaining(60); // Reset the countdown time
  };

  return (
    <div className="quiz-container">
      {quizData.length === 0 ? (
        <p>Loading quiz...</p>
      ) : showResult ? (
        <div className="result-container">
          <h2>Quiz Completed!</h2>
          <p>Your Score: {score} out of {quizData.length}</p>
          <button onClick={resetQuiz}>Retry Quiz</button>
        </div>
      ) : (
        <div className="question-container">
          <h2>Question {currentQuestion + 1}</h2>
          <p>{quizData[currentQuestion].question}</p>
          <div className="timer">Time remaining: {timeRemaining} seconds</div>
          <ul className="options-container">
            {quizData[currentQuestion].options.map((option, index) => (
              <li key={index} onClick={() => handleAnswerClick(option)}>
                {option}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Quiz;
