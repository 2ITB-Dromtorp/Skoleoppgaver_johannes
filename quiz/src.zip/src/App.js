import React from 'react';
import Quiz from './quiz';
import './App.css';

function App() {
  return (
    <div className="App">
      <Quiz />
      <div className='bildeL'></div>
    </div>
  );
}

export default App;
